package ricardodc.zork;

public class Jugador extends Persona {

	short dinero = 100;
	byte posX;
	byte posY;


	@Override
	public String toString() {
		return "Jugador [dinero=" + dinero + ", posX=" + posX + ", posY=" + posY + ", espada=" + espada + ", escudo="
				+ escudo + ", nombre=" + nombre + "]";
	}

	public byte getPosX() {
		return posX;
	}

	public void setPosX(byte posX) {
		this.posX = posX;
	}

	public byte getPosY() {
		return posY;
	}

	public void setPosY(byte posY) {
		this.posY = posY;
	}

	public Jugador(Espada espada, Escudo escudo, byte dinero) {
		super(espada, escudo);
		this.dinero = dinero;
		// TODO Auto-generated constructor stub
	}
	
	public short getDinero() {
		return dinero;
	}

	public void setDinero(short dinero) {
		this.dinero = dinero;
	}


}
