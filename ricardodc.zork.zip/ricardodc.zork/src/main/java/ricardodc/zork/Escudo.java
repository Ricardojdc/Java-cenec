package ricardodc.zork;

public class Escudo extends Objeto {

	byte defensa;

	@Override
	public String toString() {
		return "Escudo [defensa=" + defensa + ", precioVenta=" + precioVenta + ", nombre=" + nombre + "\n]";
	}

	public Escudo() {
		super();
	}

	public Escudo(byte defensa) {
		super();
		this.defensa = defensa;
	}

	public Escudo(byte precioVenta, byte defensa) {
		super(precioVenta);
		this.defensa = defensa;
	}

	public byte getDefensa() {
		return defensa;
	}

	public void setDefensa(byte defensa) {
		this.defensa = defensa;
	}

}
