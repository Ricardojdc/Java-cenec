package ricardodc.zork;

public class Escudo extends Objeto {

	byte defensa;

	public Escudo() {
		super();
	}

	public Escudo(byte defensa) {
		super();
		this.defensa = defensa;
	}

	public Escudo(byte precioVenta, byte defensa) {
		super(precioVenta);
		this.defensa = defensa;
	}

	public byte getDefensa() {
		return defensa;
	}

	public void setDefensa(byte defensa) {
		this.defensa = defensa;
	}

}
