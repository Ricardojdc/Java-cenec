package ricardodc.zork;

public class Enemigo extends Persona{
	
	

	public Enemigo(Espada espada, Escudo escudo) {
		super(espada, escudo);
		// TODO Auto-generated constructor stub
	}

}
