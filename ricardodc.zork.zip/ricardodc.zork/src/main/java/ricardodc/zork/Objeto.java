package ricardodc.zork;

public class Objeto extends EntidadConNombre {
	
	byte precioVenta;
	
	

	public Objeto() {
		super();
	}

	public Objeto(byte precioVenta) {
		super();
		this.precioVenta = precioVenta;
	}

	public byte getPrecioVenta() {
		return precioVenta;
	}

	public void setPrecioVenta(byte precioVenta) {
		this.precioVenta = precioVenta;
	}
	
	

}
