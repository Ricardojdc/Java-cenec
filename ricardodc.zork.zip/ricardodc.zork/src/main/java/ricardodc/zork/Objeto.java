package ricardodc.zork;

public class Objeto extends EntidadConNombre implements Comparable<Objeto> {
	
	byte precioVenta;
	
	

	public Objeto() {
		super();
	}

	public Objeto(byte precioVenta) {
		super();
		this.precioVenta = precioVenta;
	}

	public byte getPrecioVenta() {
		return precioVenta;
	}

	public void setPrecioVenta(byte precioVenta) {
		this.precioVenta = precioVenta;
	}

	public int compareTo(Objeto o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
