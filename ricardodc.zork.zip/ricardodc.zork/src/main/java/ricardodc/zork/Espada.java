package ricardodc.zork;

public class Espada extends Objeto {

	byte ataque;

	public Espada() {
		super();
	}

	public Espada(byte ataque) {
		super();
		this.ataque = ataque;
	}

	public Espada(byte precioVenta, byte ataque) {
		super(precioVenta);
		this.ataque = ataque;
	}

	public byte getAtaque() {
		return ataque;
	}

	public void setAtaque(byte ataque) {
		this.ataque = ataque;
	}

}
