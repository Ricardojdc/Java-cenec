package ricardodc.zork;

import java.util.PriorityQueue;
import java.util.Random;

public class Main {

	public static void main(String[] args) throws Exception {

		Mapa map = new Mapa(4);
		
		

	}

}
