package ricardodc.zork;

import java.util.PriorityQueue;
import java.util.Random;

public class Main {

	public static void main(String[] args) {

		Mapa[][] mapa = Mapa.crearMapa((byte)4);
		
		Mapa.setMonstruos(mapa);
		Mapa.setTesoro(mapa);
	//	Mapa.setTienda(mapa);
	//	Mapa.setItemsTienda();
		Mapa.jugar(mapa);
		
		
		/*
		Funciones.setMonstruos(mapa);
		Funciones.setTesoro(mapa);
		Funciones.setTienda(mapa);
		Funciones.setObjetos(mapa);
		Funciones.jugar(mapa);
		
		*/
	

	}

}
