package ricardodc.zork;

import java.util.PriorityQueue;
import java.util.Random;

public class Main {

	public static void main(String[] args) throws Exception {

		Casilla[][] mapa = Casilla.crearMapa((byte)4);
		
		Casilla.setMonstruos(mapa);
		Casilla.setTesoro(mapa);
		Casilla.setTienda(mapa);
		Casilla.jugar(mapa);
		
		
	
	

	}

}
