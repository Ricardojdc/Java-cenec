package ricardodc.zork;

public class Persona extends EntidadConNombre {
	
	Espada espada;
	Escudo escudo;
	
	public Persona(Espada espada, Escudo escudo) {
		super();
		this.espada = new Espada();
		this.escudo = new Escudo();
	}
	public Espada getEspada() {
		return espada;
	}
	public void setEspada(Espada espada) {
		this.espada = espada;
	}
	public Escudo getEscudo() {
		return escudo;
	}
	public void setEscudo(Escudo escudo) {
		this.escudo = escudo;
	}
	
	
	

}
