package ricardodc.zork;

public class Persona extends EntidadConNombre {
	
	Espada espada = new Espada();
	Escudo escudo = new Escudo();
	
	public Persona(Espada espada, Escudo escudo) {
		super();
		this.espada = espada;
		this.escudo = escudo;
	}
	public Espada getEspada() {
		return espada;
	}
	public void setEspada(Espada espada) {
		this.espada = espada;
	}
	public Escudo getEscudo() {
		return escudo;
	}
	public void setEscudo(Escudo escudo) {
		this.escudo = escudo;
	}
	
	
	

}
