package ricardodc.zork;

import java.util.ArrayList;

public class Tienda {
	
	ArrayList<Objeto> objetosVenta;
	
	public Tienda() {
		
		super();
	}

	public Tienda(ArrayList<Objeto> objetosVenta) {
		super();
		this.objetosVenta = new ArrayList<Objeto>();
	}

	public ArrayList<Objeto> getObjetosVenta() {
		
		return objetosVenta;
	}

	public void setObjetosVenta(ArrayList<Objeto> objetosVenta) {
		this.objetosVenta = objetosVenta;
	}
	
	public void removeEscudo(Escudo escudo) {
		
		objetosVenta.remove(escudo);
		
		
	}
	public void removeEspada(Espada espada) {
		
		
		objetosVenta.remove(espada);
		
	}

	@Override
	public String toString() {
		return "Tienda [objetosVenta=" + objetosVenta + "]";
	}
	
	
	

}
