package ricardodc.zork;

import java.util.PriorityQueue;

public class Tienda {
	
	PriorityQueue<Objeto> objetosVenta;
	
	public Tienda() {
		
		super();
	}

	public Tienda(PriorityQueue<Objeto> objetosVenta) {
		super();
		this.objetosVenta = new PriorityQueue<Objeto>();
	}

	public PriorityQueue<Objeto> getObjetosVenta() {
		
		return objetosVenta;
	}

	public void setObjetosVenta(PriorityQueue<Objeto> objetosVenta) {
		this.objetosVenta = objetosVenta;
	}
	
	public void removeEscudo(Escudo escudo) {
		
		objetosVenta.remove(escudo);
		
		
	}
	public void removeEspada(Espada espada) {
		
		
		objetosVenta.remove(espada);
		
	}

	@Override
	public String toString() {
		return "Tienda [objetosVenta=" + objetosVenta + "]";
	}
	
	
	

}
