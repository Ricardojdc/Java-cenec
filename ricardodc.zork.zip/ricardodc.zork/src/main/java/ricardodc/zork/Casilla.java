package ricardodc.zork;

import java.util.PriorityQueue;
import java.util.Random;
import java.util.Scanner;

public class Casilla {

	Enemigo enemigo;
	byte cantidadDinero;
	Objeto objetoAleatorio;
	Tienda tienda;
	String descripcion;

	public Casilla() {
		super();
	}

	public Casilla(String descripcion) {
		this.descripcion = descripcion;

	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Enemigo getEnemigo() {
		return enemigo;
	}

	public void setEnemigo(Enemigo enemigo) {
		this.enemigo = enemigo;
	}

	public byte getCantidadDinero() {
		return cantidadDinero;
	}

	public void setCantidadDinero(byte cantidadDinero) {
		this.cantidadDinero = cantidadDinero;
	}

	public Objeto getObjetoAleatorio() {
		return objetoAleatorio;
	}

	public void setObjetoAleatorio(Objeto objetoAleatorio) {
		this.objetoAleatorio = objetoAleatorio;
	}

	public Tienda getTienda() {
		return tienda;
	}

	public void setTienda(Tienda tienda) {
		this.tienda = tienda;
	}

	public static Casilla[][] crearMapa(byte tamano) {

		Casilla[][] mapa = new Casilla[tamano][tamano];

		for (byte i = 0; i < tamano; i++) {

			for (byte j = 0; j < tamano; j++) {

				mapa[i][j] = new Casilla(addDescripcion());

			}

		}
		return mapa;
	}

	private static String addDescripcion() {

		String descripcion = null;
		Random rand = new Random();

		switch (rand.nextInt(4)) {

		case 0:
			descripcion = "Entras en un bosque";
			break;

		case 1:
			descripcion = "Llegas a un rio";
			break;

		case 2:
			descripcion = "Llegas a una ciudad";
			break;

		case 3:
			descripcion = "Atraviesas una montaña";
			break;

		default:
			break;

		}

		return descripcion;
	}

	public static void setMonstruos(Casilla[][] mapa) {

		Random rand = new Random();
		byte nMonstruos = 4;

		while (nMonstruos > 0) {

			int pos1 = rand.nextInt(mapa.length);
			int pos2 = rand.nextInt(mapa.length);

			if (mapa[pos1][pos2].getEnemigo()== null) {

				mapa[pos1][pos2].setEnemigo(
						new Enemigo(new Espada((byte) rand.nextInt(100)), new Escudo((byte) rand.nextInt(100))));
				nMonstruos--;
			}

		}

	}

	public static void setTesoro(Casilla[][] mapa) {

		Random rand = new Random();
		byte nTesoro = 4;

		while (nTesoro > 0) {

			int pos1 = rand.nextInt(mapa.length);
			int pos2 = rand.nextInt(mapa.length);

			if (mapa[pos1][pos2].cantidadDinero == 0) {

				mapa[pos1][pos2].cantidadDinero = (byte) rand.nextInt(50);
				nTesoro--;
			}

		}

	}

	public static void setTienda(Casilla[][] mapa) {

		Random rand = new Random();
		int x;
		int y;

		x = rand.nextInt(mapa.length);
		y = rand.nextInt(mapa.length);
		mapa[x][y].tienda = new Tienda(setItemsTienda());
		mapa[x][y].tienda.setObjetosVenta(setItemsTienda());
		System.out.println(x + " " + y);

	}

	public static void setObjetos(Casilla[][] mapa) {

		Random rand = new Random();
		int nObjetos = 3;

		while (nObjetos > 0) {
			int pos1 = rand.nextInt(mapa.length);
			int pos2 = rand.nextInt(mapa.length);

			if (mapa[pos1][pos2].objetoAleatorio == null) {

				if (rand.nextBoolean()) {

					mapa[pos1][pos2].objetoAleatorio = new Espada((byte) rand.nextInt(100));

				} else {

					mapa[pos1][pos2].objetoAleatorio = new Escudo((byte) rand.nextInt(100));
				}

				nObjetos--;
			}

		}
	}

	public static PriorityQueue<Objeto> setItemsTienda() {

		PriorityQueue<Objeto> pq = new PriorityQueue<Objeto>();
		int nItems = 5;
		Random rand = new Random();

		while (nItems > 0) {

			if (rand.nextBoolean()) {

				Espada espada = new Espada((byte) rand.nextInt((byte) 100));

				pq.add(espada);

			} else {

				Escudo escudo = new Escudo((byte) rand.nextInt((byte) 100));
				pq.add(escudo);

			}

			nItems--;
		}

		return pq;
	}

	public static void jugar(Casilla[][] mapa) {

		Random rand = new Random();
		boolean muerte = false;
		boolean comprar = true;
		int nEnemigos = 4;
		byte valorTienda;
		boolean descripcion = true;
		String respuestaComprar;
		Scanner sc = new Scanner(System.in);
		int posX = (byte) rand.nextInt(mapa.length);
		int posY = (byte) rand.nextInt(mapa.length);

		Jugador jugador = new Jugador(new Espada((byte) rand.nextInt(100)), new Escudo((byte) rand.nextInt(100)),
				(byte) 100);
		jugador.setPosX((byte) posX);
		jugador.setPosY((byte) posY);

		// Orden de texto
		// Descripcion mapa, pelea monstruo, encontrar objeto/dinero, tienda, pedir
		// movimiento

		while (!muerte && nEnemigos > 0) {

			if (descripcion) {
				System.out.println("X:" + jugador.getPosX() + " Y:" + jugador.getPosY() + "\n"
						+ mapa[jugador.getPosX()][jugador.getPosY()].getDescripcion());
			}
			if (mapa[jugador.getPosX()][jugador.getPosY()].getEnemigo()!=null) {

				System.out.println("Te preparas a combatir contra un ememigo");

				if (!pelea(mapa, jugador, jugador.getPosX(), jugador.getPosY())) {

					muerte = true;

				}

			}
			if (mapa[jugador.getPosX()][jugador.getPosY()].tienda !=null) {

				System.out.println("Encuentras una tienda");

				while (comprar) {

					System.out.println("Quieres comprar? s/n");
					respuestaComprar = sc.nextLine();

					if (respuestaComprar.equals("s")) {

						System.out.println(
								mapa[jugador.getPosX()][jugador.getPosY()].tienda.getObjetosVenta().toString());

						do {

							System.out.println(
									"Introduce el numero de objeto que quieres comprar(100 para no comprar nada)");
							valorTienda = Byte.parseByte(sc.nextLine());

						} while ((valorTienda < 0 && valorTienda > mapa[jugador.getPosX()][jugador.getPosY()].tienda
								.getObjetosVenta().size()) && valorTienda == 100);
						
						if(valorTienda!=100) {
							
						
						}

					}
					else if (respuestaComprar.equals("n")) {

						comprar = false;
					} else {

						System.out.println("Opción incorrecta");
					}

				}
				comprar = true;
			}

			if (!muerte) {
				descripcion = mover(mapa, jugador);
			}

			System.out.println("---------------");

		}

	}

	public static boolean mover(Casilla[][] mapa, Jugador jugador) {

		Scanner sc = new Scanner(System.in);
		String mov;
		boolean desc = true;

		do {

			System.out.println("Introduce la direccion en la que quieres moverte:(ARRIBA,ABAJO,DERECHA,IZQUIERDA) ");
			mov = sc.nextLine();

			if (!mov.toLowerCase().equals("arriba") && !mov.toLowerCase().equals("abajo")
					&& !mov.toLowerCase().equals("derecha") && !mov.toLowerCase().equals("izquierda")) {

				System.out.println("Introduce una movimiento valido");
			}

		} while (!mov.toLowerCase().equals("arriba") && !mov.toLowerCase().equals("abajo")
				&& !mov.toLowerCase().equals("derecha") && !mov.toLowerCase().equals("izquierda"));

		if (mov.equals("arriba")) {

			if (jugador.getPosY() > 0 && jugador.getPosY() < mapa.length) {
				jugador.setPosY((byte) (jugador.getPosY() - (byte) 1));

			} else {

				System.out.println("No puedes ir en esa direccion");
				desc = false;
			}

		} else if (mov.equals("abajo")) {

			if (jugador.getPosY() >= 0 && jugador.getPosY() < mapa.length - 1) {
				jugador.setPosY((byte) (jugador.getPosY() + (byte) 1));

			} else {

				System.out.println("No puedes ir en esa direccion");
				desc = false;
			}

		} else if (mov.equals("derecha")) {

			if (jugador.getPosX() >= 0 && jugador.getPosX() < mapa.length - 1) {
				jugador.setPosX((byte) (jugador.getPosX() + (byte) 1));

			} else {

				System.out.println("No puedes ir en esa direccion");
				desc = false;
			}

		} else if (mov.equals("izquierda")) {

			if (jugador.getPosX() > 0 && jugador.getPosX() < mapa.length) {
				jugador.setPosX((byte) (jugador.getPosX() - (byte) 1));

			} else {

				System.out.println("No puedes ir en esa direccion");
				desc = false;
			}
		}

		return desc;
	}

	public static boolean pelea(Casilla[][] mapa, Jugador jugador, int posX, int posY) {

		if (jugador.getEspada().getAtaque() > mapa[posX][posY].getEnemigo().getEscudo().getDefensa()) {

			System.out.println("Has matado al enemigo " + jugador.getEspada().getAtaque()
					+ mapa[posX][posY].getEnemigo().getEscudo().getDefensa());

			//mapa[posX][posY].tieneEnemigo = false;
			return true;
		} else {

			System.out.println("Te han matado");

			return false;

		}

	}
}
