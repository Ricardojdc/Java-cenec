package ricardodc.zork;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Casilla {

	Enemigo enemigo;
	byte cantidadDinero;
	Objeto objetoAleatorio;
	Tienda tienda;
	String descripcion;

	public Casilla() {
		super();
	}

	public Casilla(String descripcion) {
		this.descripcion = descripcion;

	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Enemigo getEnemigo() {
		return enemigo;
	}

	public void setEnemigo(Enemigo enemigo) {
		this.enemigo = enemigo;
	}

	public byte getCantidadDinero() {
		return cantidadDinero;
	}

	public void setCantidadDinero(byte cantidadDinero) {
		this.cantidadDinero = cantidadDinero;
	}

	public Objeto getObjetoAleatorio() {
		return objetoAleatorio;
	}

	public void setObjetoAleatorio(Objeto objetoAleatorio) {
		this.objetoAleatorio = objetoAleatorio;
	}

	public Tienda getTienda() {
		return tienda;
	}

	public void setTienda(Tienda tienda) {
		this.tienda = tienda;
	}

	public static Casilla[][] crearMapa(byte tamano) {

		Casilla[][] mapa = new Casilla[tamano][tamano];

		for (byte i = 0; i < tamano; i++) {

			for (byte j = 0; j < tamano; j++) {

				mapa[i][j] = new Casilla(addDescripcion());

			}

		}
		return mapa;
	}

	public static String addDescripcion() {

		String descripcion = null;
		Random rand = new Random();

		switch (rand.nextInt(4)) {

		case 0:
			descripcion = "Entras en un bosque";
			break;

		case 1:
			descripcion = "Llegas a un rio";
			break;

		case 2:
			descripcion = "Llegas a una ciudad";
			break;

		case 3:
			descripcion = "Atraviesas una montaña";
			break;

		default:
			break;

		}

		return descripcion;
	}


}
