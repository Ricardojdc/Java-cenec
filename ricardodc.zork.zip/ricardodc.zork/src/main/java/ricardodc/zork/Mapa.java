package ricardodc.zork;

import java.util.PriorityQueue;
import java.util.Random;

public class Mapa {

	Enemigo enemigo;
	byte cantidadDinero = 0;
	Objeto objetoAleatorio;
	Tienda tienda;
	String descripcion;
	boolean tieneEnemigo = false;

	public Mapa() {
		super();
	}

	public Mapa(String descripcion) {
		this.descripcion = descripcion;

	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Enemigo getEnemigo() {
		return enemigo;
	}

	public void setEnemigo(Enemigo enemigo) {
		this.enemigo = enemigo;
	}

	public byte getCantidadDinero() {
		return cantidadDinero;
	}

	public void setCantidadDinero(byte cantidadDinero) {
		this.cantidadDinero = cantidadDinero;
	}

	public Objeto getObjetoAleatorio() {
		return objetoAleatorio;
	}

	public void setObjetoAleatorio(Objeto objetoAleatorio) {
		this.objetoAleatorio = objetoAleatorio;
	}

	public Tienda getTienda() {
		return tienda;
	}

	public void setTienda(Tienda tienda) {
		this.tienda = tienda;
	}

	public static Mapa[][] crearMapa(byte tamano) {

		Mapa[][] mapa = new Mapa[tamano][tamano];

		for (byte i = 0; i < tamano; i++) {

			for (byte j = 0; j < tamano; j++) {

				mapa[i][j] = new Mapa(addDescripcion());

			}

		}
		return mapa;
	}

	public static String addDescripcion() {

		String descripcion = null;
		Random rand = new Random();

		switch (rand.nextInt(4)) {

		case 0:
			descripcion = "Entras en un bosque";
			break;

		case 1:
			descripcion = "Llegas a un rio";
			break;

		case 2:
			descripcion = "Llegas a una ciudad";
			break;

		case 3:
			descripcion = "Atraviesas una montaña";
			break;

		default:
			break;

		}

		return descripcion;
	}

	public static void setMonstruos(Mapa[][] mapa) {

		Random rand = new Random();
		byte nMonstruos = 4;

		while (nMonstruos > 0) {

			int pos1 = rand.nextInt(mapa.length);
			int pos2 = rand.nextInt(mapa.length);

			if (mapa[pos1][pos2].tieneEnemigo == false) {

				mapa[pos1][pos2].setEnemigo(
						new Enemigo(new Espada((byte) rand.nextInt(100)), new Escudo((byte) rand.nextInt(100))));
				mapa[pos1][pos2].tieneEnemigo = true;
				nMonstruos--;
			}

		}

	}

	public static void setTesoro(Mapa[][] mapa) {

		Random rand = new Random();
		byte nTesoro = 4;

		while (nTesoro > 0) {

			int pos1 = rand.nextInt(mapa.length);
			int pos2 = rand.nextInt(mapa.length);

			if (mapa[pos1][pos2].cantidadDinero == 0) {

				mapa[pos1][pos2].cantidadDinero = (byte) rand.nextInt(50);
				nTesoro--;
			}

		}

	}

	public static void setTienda(Mapa[][] mapa) {

		Random rand = new Random();

		mapa[rand.nextInt(mapa.length)][rand.nextInt(mapa.length)].tienda = new Tienda(setItemsTienda());

	}

	public static void setObjetos(Mapa[][] mapa) {

		Random rand = new Random();
		int nObjetos = 3;

		while (nObjetos > 0) {
			int pos1 = rand.nextInt(mapa.length);
			int pos2 = rand.nextInt(mapa.length);

			if (mapa[pos1][pos2].objetoAleatorio == null) {

				if (rand.nextBoolean()) {

					mapa[pos1][pos2].objetoAleatorio = new Espada((byte) rand.nextInt(100));

				} else {

					mapa[pos1][pos2].objetoAleatorio = new Escudo((byte) rand.nextInt(100));
				}

				nObjetos--;
			}

		}
	}

	public static PriorityQueue<Objeto> setItemsTienda() {

		PriorityQueue<Objeto> pq = new PriorityQueue<Objeto>();
		int nItems = 5;
		Random rand = new Random();

		while (nItems > 0) {

			if (rand.nextBoolean()) {

				Espada espada = new Espada((byte) rand.nextInt((byte) 100));

				pq.offer(espada);

			} else {

				Escudo escudo = new Escudo((byte) rand.nextInt((byte) 100));
				pq.offer(escudo);

			}

			nItems--;
		}

		return pq;
	}

	public static void jugar(Mapa[][] mapa) {

		Random rand = new Random();
		boolean muerte = false;
		int nEnemigos = 4;
		int posX = (byte) rand.nextInt(mapa.length);
		int posY = (byte) rand.nextInt(mapa.length);
		

		Jugador jugador = new Jugador(new Espada((byte) rand.nextInt(100)), new Escudo((byte) rand.nextInt(100)),(byte) 100);
		jugador.setPosX((byte)posX);
		jugador.setPosY((byte)posY);
		
		//Orden de texto
		//Descripcion mapa, pelea monstruo, encontrar objeto/dinero, tienda, pedir movimiento 

		System.out.println(jugador.getPosX() + " " + jugador.getPosY() + "\n"
				+ mapa[jugador.getPosX()][jugador.getPosY()].getDescripcion());
		
		while(!muerte && nEnemigos > 0) {
			
			if(mapa[jugador.getPosX()][jugador.getPosY()].tieneEnemigo) {
				
				System.out.println("Te preparas a combatir contra un ememigo");
				
				//El jugador siempre ataca primero
				
				System.out.println(jugador.getEspada().getAtaque());
				
				if(jugador.getEspada().getAtaque() > mapa[posX][posY].getEnemigo().getEscudo().getDefensa()) {
					
					System.out.println("Has matado al enemigo"+jugador.getEspada().getAtaque()+mapa[posX][posY].getEnemigo().getEscudo().getDefensa());
				}else {
					
					System.out.println("Te han frito");
					
				}
				
				
				
				muerte = true;
			}
			
			
		}

	}

}
