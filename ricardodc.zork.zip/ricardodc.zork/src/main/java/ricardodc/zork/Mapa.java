package ricardodc.zork;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Mapa {
	private static Casilla[][] cuadricula;
	

	public Mapa(int tamano) {
		super();
		 cuadricula = new Casilla[tamano][tamano];
		for(byte i=0;i < tamano;i++) {
			
			for(byte j=0;j < tamano;j++) {
				
				this.cuadricula[i][j] = new Casilla(Casilla.addDescripcion());
				
			}
			
		}
		setMonstruo();	
		setTesoro();
		setTienda();
		jugar();
		
	}
	
	private void setMonstruo() {
		
		Random rand = new Random();
		byte nMonstruos = 4;

		while (nMonstruos > 0) {

			int pos1 = rand.nextInt(cuadricula.length);
			int pos2 = rand.nextInt(cuadricula.length);

			if (cuadricula[pos1][pos2].getEnemigo() == null) {

				cuadricula[pos1][pos2].setEnemigo(
						new Enemigo(new Espada((byte) rand.nextInt(100)), new Escudo((byte) rand.nextInt(100))));
				nMonstruos--;
			}

		}
		
	}
	
	private void setTesoro() {

		Random rand = new Random();
		byte nTesoro = 4;

		while (nTesoro > 0) {

			int pos1 = rand.nextInt(cuadricula.length);
			int pos2 = rand.nextInt(cuadricula.length);

			if (cuadricula[pos1][pos2].cantidadDinero == 0) {

				cuadricula[pos1][pos2].cantidadDinero = (byte) rand.nextInt(50);
				nTesoro--;
			}

		}

	}

	private void setTienda() {

		Random rand = new Random();
		int x;
		int y;

		x = rand.nextInt(cuadricula.length);
		y = rand.nextInt(cuadricula.length);
		cuadricula[x][y].tienda = new Tienda(setItemsTienda());
		cuadricula[x][y].tienda.setObjetosVenta(setItemsTienda());
		System.out.println(x + " " + y);

	}
	private ArrayList<Objeto> setItemsTienda() {

		ArrayList<Objeto> pq = new ArrayList<Objeto>();
		int nItems = 5;
		Random rand = new Random();

		while (nItems > 0) {

			if (rand.nextBoolean()) {

				Espada espada = new Espada((byte) rand.nextInt((byte) 100));

				pq.add(espada);

			} else {

				Escudo escudo = new Escudo((byte) rand.nextInt((byte) 100));
				pq.add(escudo);

			}

			nItems--;
		}

		return pq;
	}
	
	private static void jugar() {

		Random rand = new Random();
		boolean muerte = false;
		boolean comprar = true;
		int nEnemigos = 4;
		byte valorTienda;
		boolean descripcion = true;
		String respuestaComprar;
		Scanner sc = new Scanner(System.in);
		int posX = (byte) rand.nextInt(cuadricula.length);
		int posY = (byte) rand.nextInt(cuadricula.length);

		Jugador jugador = new Jugador(new Espada((byte) rand.nextInt(100)), new Escudo((byte) rand.nextInt(100)),
				(byte) 100);
		jugador.setPosX((byte) posX);
		jugador.setPosY((byte) posY);

		// Orden de texto
		// Descripcion mapa, pelea monstruo, encontrar objeto/dinero, tienda, pedir
		// movimiento

		while (!muerte && nEnemigos > 0) {

			if (descripcion) {
				System.out.println("X:" + jugador.getPosX() + " Y:" + jugador.getPosY() + "\n"
						+ cuadricula[jugador.getPosX()][jugador.getPosY()].getDescripcion());
			}
			if (cuadricula[jugador.getPosX()][jugador.getPosY()].getEnemigo() != null) {

				System.out.println("Te preparas a combatir contra un ememigo");

				if (!pelea(jugador, jugador.getPosX(), jugador.getPosY())) {

					muerte = true;

				}

			}
			if (cuadricula[jugador.getPosX()][jugador.getPosY()].tienda != null) {

				System.out.println("Encuentras una tienda");

				while (comprar) {

					System.out.println("Quieres comprar? s/n");
					respuestaComprar = sc.nextLine();

					if (respuestaComprar.equals("s")) {

						System.out.println(
								cuadricula[jugador.getPosX()][jugador.getPosY()].tienda.getObjetosVenta().toString());

						do {

							System.out.println(
									"Introduce el numero de objeto que quieres comprar(100 para no comprar nada)");
							valorTienda = Byte.parseByte(sc.nextLine());

						} while ((valorTienda < 0 && valorTienda > cuadricula[jugador.getPosX()][jugador.getPosY()].tienda
								.getObjetosVenta().size()-1) && valorTienda == 100);

						if (valorTienda != 100) {

							if (cuadricula[jugador.posX][jugador.posY].tienda.objetosVenta.get(valorTienda).getClass()
									.getSimpleName().equals("Escudo")) {

								jugador.setEscudo(
										(Escudo) cuadricula[jugador.posX][jugador.posY].tienda.objetosVenta.get(valorTienda));

							}
							if (cuadricula[jugador.posX][jugador.posY].tienda.objetosVenta.get(valorTienda).getClass()
									.getSimpleName().equals("Espada")) {

								jugador.setEspada(
										(Espada) cuadricula[jugador.posX][jugador.posY].tienda.objetosVenta.get(valorTienda));

							}

						}

					} else if (respuestaComprar.equals("n")) {

						comprar = false;
					} else {

						System.out.println("Opción incorrecta");
					}

				}
				comprar = true;
			}

			if (!muerte) {
				descripcion = mover(jugador);
			}

			System.out.println("---------------");

		}

	}
	private static boolean mover( Jugador jugador) {

		Scanner sc = new Scanner(System.in);
		String mov;
		boolean desc = true;

		do {

			System.out.println("Introduce la direccion en la que quieres moverte:(ARRIBA,ABAJO,DERECHA,IZQUIERDA) ");
			mov = sc.nextLine();

			if (!mov.toLowerCase().equals("arriba") && !mov.toLowerCase().equals("abajo")
					&& !mov.toLowerCase().equals("derecha") && !mov.toLowerCase().equals("izquierda")) {

				System.out.println("Introduce una movimiento valido");
			}

		} while (!mov.toLowerCase().equals("arriba") && !mov.toLowerCase().equals("abajo")
				&& !mov.toLowerCase().equals("derecha") && !mov.toLowerCase().equals("izquierda"));

		if (mov.equals("arriba")) {

			if (jugador.getPosY() > 0 && jugador.getPosY() < cuadricula.length) {
				jugador.setPosY((byte) (jugador.getPosY() - (byte) 1));

			} else {

				System.out.println("No puedes ir en esa direccion");
				desc = false;
			}

		} else if (mov.equals("abajo")) {

			if (jugador.getPosY() >= 0 && jugador.getPosY() < cuadricula.length - 1) {
				jugador.setPosY((byte) (jugador.getPosY() + (byte) 1));

			} else {

				System.out.println("No puedes ir en esa direccion");
				desc = false;
			}

		} else if (mov.equals("derecha")) {

			if (jugador.getPosX() >= 0 && jugador.getPosX() < cuadricula.length - 1) {
				jugador.setPosX((byte) (jugador.getPosX() + (byte) 1));

			} else {

				System.out.println("No puedes ir en esa direccion");
				desc = false;
			}

		} else if (mov.equals("izquierda")) {

			if (jugador.getPosX() > 0 && jugador.getPosX() < cuadricula.length) {
				jugador.setPosX((byte) (jugador.getPosX() - (byte) 1));

			} else {

				System.out.println("No puedes ir en esa direccion");
				desc = false;
			}
		}

		return desc;
	}

	private static boolean pelea( Jugador jugador, int posX, int posY) {

		if (jugador.getEspada().getAtaque() > cuadricula[posX][posY].getEnemigo().getEscudo().getDefensa()) {

			System.out.println("Has matado al enemigo " + jugador.getEspada().getAtaque()
					+ cuadricula[posX][posY].getEnemigo().getEscudo().getDefensa());

			
			return true;
		} else {

			System.out.println("Te han matado");

			return false;

		}

	}

}
