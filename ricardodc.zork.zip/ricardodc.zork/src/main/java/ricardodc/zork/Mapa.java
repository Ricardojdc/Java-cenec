package ricardodc.zork;

public class Mapa {
	private Casilla[][] mapa;

}
